import socket #importing socket class
import subprocess #importing subprocess class
SERVER_ADDRESS = (HOST, PORT) = '', 8888 #setting the server host to be "any" and the server port to be 8888
REQUEST_QUEUE_SIZE = 5 # If it takes a long time to process a single request, any requests that arrive while the server is busy are placed into a queue


def handle_request(client_connection): #Process a single request
    request = client_connection.recv(1024) #will read at most 1024 bytes
    from docx import Document #importing module document
    import os #importing os class
    document = Document() #creates a new document from the built-in default template
    m = request.decode() #decoding the encryption
    msgs = [] #creating an array
    for line in m.splitlines(): #splitting the message in m
        msgs.append(line) #appending action takes place here

    message = '' #initially the message will be empty
    for line in msgs: #for every line in the message variable
        if line == '': #check for the blank space
            message += msgs[msgs.index(line) + 1] #get the index of next line if there is a blank space
    if "cancel mute" in message and "print" not in message: #cancelling mute operation if the string cancel mute is in the message
        os.startfile('C:\\nircmd\\GoogleScripts\\unmutesystemvolume') #calling unmute program
    elif "turn off" in message and "print" not in message: #if there is a string called shutdown o turm off
        os.system("shutdown /s") #execute this command
    elif "restart" in message and "print" not in message: #if there is a string called restart
        os.system("shutdown /r") #execute restart
    elif "sleep" in message and "print" not in message: #if there is a string called sleep
        os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0") #put the system to sleep
    elif "increase brightness" in message and "print" not in message: #if there is a string called increase brightness
        os.startfile('C:\\nircmd\\GoogleScripts\\increasebrightness') #increase brightness
    elif "decrease brightness" in message and "print" not in message: #if there is a string called decrease brightnes
        os.startfile('C:\\nircmd\\GoogleScripts\\decreasebrightness') #decrease brightness
    elif "decrease volume" in message and "print" not in message: #if there is a string called decrease volume
        os.startfile('C:\\nircmd\\GoogleScripts\\decreasevolume') #decrease volume
    elif "increase volume" in message and "print" not in message: #if there is a string called increase volume
        os.startfile('C:\\nircmd\\GoogleScripts\\increasevolume') #increase volume
    elif "mute" in message and "print" not in message: #if there is a string called mute
        os.startfile('C:\\nircmd\\GoogleScripts\\mutesystemvolume') #mute the system volume
    elif "cancel shutdown" in message and "print" not in message: #if there is a string called abort or cancel shutdown
        os.startfile('C:\\nircmd\\GoogleScripts\\abortshutdown') #shutdown will be cancelled
    elif "print" in message: #if print in the message string
        msg = message.replace("print ","") #trimming operation follows
        print(msg) #message will be printed
        document.add_paragraph(msg) #paragraphs in the msgs variable will be added
        document.save('C:\\Python3\\New.docx') #document is saved
        os.system('cd C:\\Python3') #go to that directory
        os.system('start New.docx') #open that file


def serve_forever(): #function definition
    listen_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #This is a Python type object that represents the socket object type. SOCK_STREAM means that it is a TCP socket.AF_INET is an address family
    listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) #SOL_SOCKET is the socket layer itself. Used for options that are protocol independent
    listen_socket.bind(SERVER_ADDRESS) #binding of socket takes place here
    listen_socket.listen(REQUEST_QUEUE_SIZE) #listen to the queue size which is 5 in our case
    print('Serving HTTP on port {port} ...'.format(port=PORT)) #print the server port along with the message

    while True: #while the above statement is true

        client_connection, client_address = listen_socket.accept() #accept all the incoming client requests
        handle_request(client_connection) #handle the client connection

        client_connection.close() #close the connection and hence the client

if __name__ == '__main__':
    serve_forever() #Handle requests until an explicit shutdown() request

