STEPS TO EXECUTE THE OPERATION.
1.Run the python web server(WebServer.py) which starts at port 8888 and waits to accept all incoming requests.
2. Open cmd.
3. Type �ngrok.exe http 8888� to expose the port.
4. Go to IFTTT(make sure of your gmail login)
5. Create an applet using google assistant for �IF THIS� part and           Webhooks for �If that� part.
6. Give the �say a phrase with a text ingredient� and continue with the options next.
7. Go to Webhooks.
8. Give the url of ngrok for port 8888 for which the server was started.
9. Give the method as POST and the content type to be application/url or JSON
10. Finish the operation.
11. Now say a phrase in your google assistant for example �Hey Google, Can you shutdown�
The system will shutdown
Now say �Hey google, can you print this is an advanced networking course� and it will be printed automatically by opening a word document.
12. This way, the project works for any command that is necessary

13. To control multiple computers, say a phrase as "Hey google Computer print xyz" and it will be printed on the other computer by opening a word document there.
(�Can you� for computer1, �system� for computer 2 and �computer� for computer3.)

Hey google, can you print xyz will print on computer1.
Hey google, system print xyz will print on computer2.
Hey google, computer print xyz will print on computer3.

The same applies for every other task.
